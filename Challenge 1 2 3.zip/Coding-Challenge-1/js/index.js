
function formWatch(){
	let btn = document.getElementById('btn');


	btn.addEventListener('click', (event) => {
		event.preventDefault();

		let input = document.getElementById('query');
		let results = document.querySelector('.js-search-results');

		let url = `https://pokeapi.co/api/v2/pokemon/${input.value}`;

		let settings = {
			method : 'GET'
		};

		fetch(url, settings)
			.then(response => {
				if(response.ok){
					return response.json();
				}
				results.innerHTML = "Pokemon not found.";
			})
			.then(responseJSON => {
				console.log(responseJSON);
				results.innerHTML = 
				`
				<div>
					Name: ${responseJSON.name}
				</div>
				<div>
					Sprite:<img src = "${responseJSON.sprites.back_default}">
				</div>
				`
				for (let i = 0; i < responseJSON.moves.length; i++)
				{
					results.innerHTML += `<div>${responseJSON.moves[i].move.name}</div>`;
				}

				for (let i = 0; i < responseJSON.stats.length; i++)
				{
					results.innerHTML += `
					<div>
						${responseJSON.stats[i].stat.name}
						${responseJSON.stats[i].base_stat}
					</div>`;
				}
			})
			.catch(err => {
				results.innerHTML = "Pokemon not found.";
			});


	});
}


function init(){
	formWatch();
}

init();
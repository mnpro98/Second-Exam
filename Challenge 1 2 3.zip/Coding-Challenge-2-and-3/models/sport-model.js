const mongoose = require( 'mongoose' );

const sportsCollectionSchema = mongoose.Schema({
	name : {
		type : String
	},
	num_players : {
		type : Number
	},
	id : {
		type: Number,
		required : true,
		unique : true
	}
});

const sportsCollection = mongoose.model('sports', sportsCollectionSchema);

const sports = {
	postSport : function(newSport){
		return sportsCollection
			.create(newSport)
			.then(createdSport => {
				return createdSport;
			})
			.catch(err => {
				return err;
			});
	}
};

module.exports = {sports};
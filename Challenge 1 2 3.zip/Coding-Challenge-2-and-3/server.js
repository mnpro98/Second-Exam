const express = require( 'express' );
const bodyParser = require( 'body-parser' );
const {sports} = require('./models/sport-model');
const mongoose = require( 'mongoose' );
const jsonParser = bodyParser.json();
const { DATABASE_URL, PORT } = require( './config' );

const app = express();

app.use(express.static("public"));


/* Your code goes here */

app.post('/sports/addSport/:sportId', jsonParser, (req, res) => {
    let sportId = req.params.sportId;

    let name = req.body.name;
    let num_pl = req.body.num_players;
    let id = req.body.id;

    if(!name || !num_pl || !id){
        res.statusMessage = "Some parameters are missing";
        return res.status(406).end();
    } else if (sportId != id) {
        res.statusMessage = "Ids do not match";
        return res.status(409).end();
    } else {

        const newSport = {
            name,
            num_pl,
            id
        };

        sports
            .postSport(newSport)
            .then(result => {
                return res.status(201).json(result);
            })
            .catch(err => {
                res.statusMessage = "Something went wrong with the DB, try again later.";
                return res.status(500).end();
            });
    }
});


app.listen( PORT, () => {
    console.log( "This server is running on port 8080" );
    new Promise( ( resolve, reject ) => {
        const settings = {
            useNewUrlParser: true, 
            useUnifiedTopology: true, 
            useCreateIndex: true
        };
        mongoose.connect( DATABASE_URL, settings, ( err ) => {
            if( err ){
                return reject( err );
            }
            else{
                console.log( "Database connected successfully." );
                return resolve();
            }
        })
    })
    .catch( err => {
        console.log( err );
    });
});